create view modeldetailheader as
SELECT t.model_id,
       t.item_id,
       t.type,
       t.description
FROM (SELECT ((m.modeldetails -> 'model_id'::text) ->> 'name'::text) AS model_id,
             0                                                       AS item_id,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 0) ->>
              'type'::text)                                          AS type,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 0) ->>
              'description'::text)                                   AS description,
             m.modeldetails
      FROM modeldetails m
      UNION ALL
      SELECT ((m.modeldetails -> 'model_id'::text) ->> 'name'::text) AS model_id,
             1                                                       AS item_id,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 1) ->>
              'type'::text)                                          AS type,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 1) ->>
              'description'::text)                                   AS description,
             m.modeldetails
      FROM modeldetails m
      UNION ALL
      SELECT ((m.modeldetails -> 'model_id'::text) ->> 'name'::text) AS model_id,
             2                                                       AS item_id,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 2) ->>
              'type'::text)                                          AS type,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 2) ->>
              'description'::text)                                   AS description,
             m.modeldetails
      FROM modeldetails m
      UNION ALL
      SELECT ((m.modeldetails -> 'model_id'::text) ->> 'name'::text) AS model_id,
             3                                                       AS item_id,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 3) ->>
              'type'::text)                                          AS type,
             (((((m.modeldetails -> 'output'::text) -> 'variable_importances'::text) -> 'columns'::text) -> 3) ->>
              'description'::text)                                   AS description,
             m.modeldetails
      FROM modeldetails m) t;

alter table modeldetailheader
  owner to postgres;

